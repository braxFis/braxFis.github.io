<?php

namespace app\models;

class RAWG_API{

    /**protected string $apiKey = "8bc47dab600645ac9164f534d0182baf";**/
    protected string $baseUrl = "https://api.rawg.io/api/";

    //When understanding what is happening under the hood
    //Start adding more functions from here

}
