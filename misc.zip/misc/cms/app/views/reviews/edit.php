<form action="/review/update/<?php echo $review->id;?>" method="POST">
  <input type="hidden" name="id" id="<?php echo $review->id;?>">
  <div>
      <label for="title">Review Title</label>
      <input type="text" name="title" id="title" value="<?php echo $review->title;?>">
      <label for="subtitle">Review Subtitle</label>
      <input type="text" name="subtitle" id="subtitle" value="<?php echo $review->subtitle;?>">
      <label for="content">Review Content</label>
      <textarea name="content" id="content" cols="30" rows="10"><?php echo $review->content;?></textarea>
      <label for="date">Review Date</label>
      <?php echo $review->date;?>
      <label for="author">Review Author</label>
      <input type="text" name="author" id="author" value="<?php echo $review->author;?>">
      <label for="genre">Review Genre</label>
      <input type="text" name="genre" id="genre" value="<?php echo $review->genre;?>">
      <label for="media">Review Media</label>
      <input type="text" name="media" id="media" value="<?php echo $review->media;?>">
      <label for="platform">Review Platform</label>
      <input type="text" name="platform" id="platform" value="<?php echo $review->platform;?>">
      <label for="status">Review Status</label>
      <select name="status" id="status">
        <option value="draft">Draft</option>
        <option value="published">Published</option>
      </select>
      <label for="tags">Review Tags</label>
      <input type="text" name="tags" id="tags" value="<?php echo $review->tags;?>">
    <label for="rating">Rating</label>
    <input type="text" name="rating" id="rating" value="<?php echo $review->rating;?>">

    <label for="score_id">Score ID</label>
    <input type="text" name="score_id" id="score_id" value="<?php echo $review->score_id?>">
  </div>

  <div class="conclusion">
    <label for="conclusion">Conclusion</label>
    <textarea name="conclusion" id="conclusion" cols="30" rows="10">
      ...
    </textarea>
  </div>

  <div class="scorecard">
    <label for="">TBD Point 1</label>
    <label for="">TBD Point 2</label>
    <label for="">TBD Point 3</label>
    <label for="">TBD Point 4</label>
    <label for="">TBD Point 5</label>
  </div>
  <button type="submit">Update Review</button>
</form>
<?php
