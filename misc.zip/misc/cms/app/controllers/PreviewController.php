<?php

namespace app\controllers;

require_once __DIR__ . '/../models/Preview.php';

class PreviewController extends BaseController {
  private $model;

  public function __construct() {
    $this->model = new \app\models\Preview;
  }

  public function indiePreview($id){
    $preview = $this->model->getPreview($id);
    ob_start();
    require __DIR__ . '/../views/previews/indiePreview.php';
    $content = ob_get_clean();
    include __DIR__ . '/../views/layout.php';
  }
  public function listPreview(){
    $previews = $this->model->getPreviews();
    ob_start();
    require __DIR__ . '/../views/previews/listPreview.php';
    $content = ob_get_clean();
    include __DIR__ . '/../views/layout.php';
  }

  public function index() {
    $previews = $this->model->getPreviews();
    ob_start();
    require __DIR__ . '/../views/previews/index.php';
    $content = ob_get_clean();
    include __DIR__ . '/../views/layout.php';
  }

  public function create(){
    $this->requireAdmin();
    $previewModel = new \app\models\Preview;
    $previews = $previewModel->getPreviews();
    //$menus
    //$footers
    ob_start();
    require __DIR__ . '/../views/previews/create.php';
    $content = ob_get_clean();
    require __DIR__ . '/../views/layout.php';
  }

  public function store($postData){
    $this->requireAdmin();
    $this->model->create($postData);
    header('Location: /preview');
  }

  public function edit($id){
    $preview = $this->model->getPreview($id);
    if($preview == null){
      require __DIR__ . '/../views/errors/404.php';
      exit;
    }
    ob_start();
    require __DIR__ . '/../views/previews/edit.php';
    $content = ob_get_clean();
    include __DIR__ . '/../views/layout.php';
  }

  public function update($id, $data){
    $this->requireAdmin();
    $this->model->update($id, $data);
    header('Location: /preview');
    exit;
  }

  public function delete($id){
    $this->requireAdmin();
    $this->model->delete($id);
    header('Location: /preview');
    exit;
  }

}
